
import java.util.HashMap;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mark
 */
public class IdAndPasswords {
    HashMap<String,String> Logininfo = new HashMap<String,String>();
    
    IdAndPasswords(){
        Logininfo.put("Bro","Fene");
        Logininfo.put("Siz1","Sela");
        Logininfo.put("Siz2","Sonia");
    }
    protected HashMap getLoginInfo(){
        return Logininfo;
    }
}
